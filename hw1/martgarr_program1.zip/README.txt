/**************************************************************************
  Author: Garrett Martin
  Email: martgarr@oregonstate.edu
  Date: 28/9/2020
  Class: CS344
  Section: 001
  Assignment: 1 - Movies
***************************************************************************/

All you need to do to compile on os1 is extract the zip and then use the make command.

However, if you insist on not doing that you can always use:

  gcc --std=gnu99 main.c functions.c -o movies

to achieve the same result.
