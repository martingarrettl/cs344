/**************************************************************************
  Author: Garrett Martin
  Email: martgarr@oregonstate.edu
  Date: 18/10/2020
  Class: CS344
  Section: 001
  Assignment: 2 - Files & Directories
***************************************************************************/

All you need to do to compile on os1 is extract the zip and then use the make command.

However, if you insist on not doing that you can always use:

  gcc --std=gnu99 main.c functions.c -o movies_by_year -g

to achieve the same result.
